package com.example.autenticazione;

public class Retailer {

    private String longitude;
    private String latitude;
    private String name;
    private String id_retailer;

}
