package com.example.autenticazione;

public class Partner {

    private int id_partner;
    private String name;
    private String description;
}
