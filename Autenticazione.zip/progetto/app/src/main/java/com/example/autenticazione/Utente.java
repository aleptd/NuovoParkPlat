package com.example.autenticazione;

public class Utente {


    public Utente(String email, String nome, String token) {
        this.email = email;
        this.nome = nome;
        this.token = token;
    }

    String email;
    String nome;
String token;

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getEmail() {
        return email;
    }

    public String getNome() {
        return nome;
    }

    public String getToken() {
        return token;
    }

    public Utente() {
    }


}

