package com.example.autenticazione;

public class Buono {

    private int id_buono;

    private int id_partner;
    private String image;
    private float value;
    private String description;

}
