package com.example.autenticazione;

public class Marker {

    private int id_marker;

    private long longi;
    private long lat;
    private boolean category;
    private String name;
    private String description;

}
